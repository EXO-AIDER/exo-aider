function [y] = my_resample(x,p,q)
    y = resample(x,p,q);
end

