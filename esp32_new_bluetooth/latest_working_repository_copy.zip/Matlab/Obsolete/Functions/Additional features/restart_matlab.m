function [] = restart_matlab()
!matlab &
exit 
