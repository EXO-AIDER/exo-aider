classdef SppBluetoothSettings < handle
    properties
        sample_frequency = 1000
        send_frequency = 75
        buffer_size = 1000
    end
end

