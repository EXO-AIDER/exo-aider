#include <iostream>
#include "BluetoothSerial.h" 

using namespace std; 

char ReinterpretCast(int Value);
void GetTask(BluetoothSerial& ConnectionBT);